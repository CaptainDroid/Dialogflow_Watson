var express = require('express')
var app = express()
var http = require('http').Server(app);
var io = require('socket.io')(http);
count = 0;
global.socket2;
global.user_id;


http.listen(3000, function() {
    console.log("Bot listening on port 3000...");
});

app.get('/', function(req, res){
res.sendFile(__dirname + '/index.html');
});





//CONSOLE BOT CONSOLEBOT.JS
var Botkit = require(__dirname + '/node_modules/botkit/lib/CoreBot.js');
var readline = require('readline');


function TextBot(configuration) {

    // Create a core botkit bot
    var text_botkit = Botkit(configuration || {});


    text_botkit.middleware.spawn.use(function(bot, next) {
        
        text_botkit.listenStdIn(bot);
        next();

    });

    text_botkit.middleware.format.use(function(bot, message, platform_message, next) {
        // clone the incoming message
        for (var k in message) {
            platform_message[k] = message[k];
        }

        next();
    });

    text_botkit.defineBot(function(botkit, config) {

        var bot = {
            botkit: botkit,
            config: config || {},
            utterances: botkit.utterances,
        };

        bot.createConversation = function(message, cb) {
            botkit.createConversation(this, message, cb);
        };

        bot.startConversation = function(message, cb) {
            botkit.startConversation(this, message, cb);
        };

        bot.send = function(message, cb) {
            console.log('BOT:', message.text);
            if (cb) {
                cb();
            }
        };

        bot.reply = function(src, resp, cb) {
            var msg = {};

            if (typeof(resp) == 'string') {
                msg.text = resp;
            } else {
                msg = resp;
            }

            msg.channel = src.channel;

            bot.say(msg, cb);
        };

        bot.findConversation = function(message, cb) {
            botkit.debug('CUSTOM FIND CONVO', message.user, message.channel);
            for (var t = 0; t < botkit.tasks.length; t++) {
                for (var c = 0; c < botkit.tasks[t].convos.length; c++) {
                    if (
                        botkit.tasks[t].convos[c].isActive() &&
                        botkit.tasks[t].convos[c].source_message.user == message.user
                    ) {
                        botkit.debug('FOUND EXISTING CONVO!');
                        cb(botkit.tasks[t].convos[c]);
                        return;
                    }
                }
            }

            cb();
        };

        return bot;

    });

    text_botkit.listenStdIn = function(bot) {
        text_botkit.startTicking();
        //ADDED BY AKASH START
        io.on('connection', function(socket) {
            global.socket2 = socket;
            global.user_id = socket.id
                console.log("A user connected");
                socket.on('disconnect', function(){
                    console.log("User disconnected");
                });

        socket.on('chat message', function(msg) {

            console.log("The id is "+socket.id+"\nand the message received is "+msg);
                var message = {
                text: msg,
                user: 'user',
                channel: 'text',
                timestamp: Date.now()
            };
            console.log("THIS IS THE MESSAGE THAT IS BEING FORMED"+JSON.stringify(message, null, 2)); //WRITTEN BY AKASH
            //io.emit('chat message', msg);
            //socket.broadcast.to(socket.id).emit('chat message', "THIS IS A SAMPLE")
            text_botkit.ingest(bot, message, null);
            
        })
        
    });
   
        // var rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: false });
        // rl.on('line', function(line) {
        //     var message = {
        //         text: line,
        //         user: 'user',
        //         channel: 'text',
        //         timestamp: Date.now()
        //     };

        //Added by akash- start
        
            

        //});
    };

    return text_botkit;
};

module.exports = TextBot;



















//THIS IS AN ATTEMPT TO HANDLE THE UTTERANCE USING MIDDLEWARES USING APIAI FIRST AND THEN MOVING ON TO WATSON IF A MATCH IS NOT FOUND

var botkit = require('botkit');
var apiaibotkit = require('api-ai-botkit');
var watsonMiddleware = require('botkit-middleware-watson')({
    username: 'ddd50b2d-9a4a-455a-99b0-0142e5048712', //watson userid
    password: 'ba7gvTBQH5cE', //watson pwd
    workspace_id: '68bc5bf5-2a55-4033-a8b2-b18f41523380',
    version_date: '2017-05-26',
    minimum_confidence: 0.50, // (Optional) Default is 0.75
  });
const apiaiToken = "d50833f4f134465bb3a1ad8567ca87a7";
var apiaiMiddleware = require('botkit-middleware-dialogflow')({
  token: apiaiToken
})
const slackToken = "xoxb-296075056741-vSKtcJr25J6M8K1Ldqy6Z61Z";
var apiai = apiaibotkit(apiaiToken);

var controller = botkit.consolebot({
  debug : false,
  log : false
});

var bot2 = controller.spawn({
  //token : slackToken
})//.startRTM();


//MIDDLEWARE FOR APIAI
controller.middleware.receive.use(apiaiMiddleware.receive);
//MIDDLEWARE FOR WATSON
controller.middleware.receive.use(watsonMiddleware.receive);

//SOME LOCAL VARIABLES HERE
var count = 0;






//                      EVERYTHING FOR API.AI HERE
////////////////////////////////////////////////////////////////////////////////////////////////


// function myfn(callback2) {
// apiai.all( function(message, resp, bot2) {
//   console.log("Action : "+resp.result.action);
//   if(resp.result.action == 'input.unknown') 
//   console.log("Yes")
//   else console.log("No")
//   if(resp.result.action == 'input.unknown') 
//     return callback2(true);
//   else return callback2(false);
// });
// }

// function myFunction(message, bot2, callback) {
//   apiai.process(message, bot2);
//   myfn(function(val) {
//    // return val;
//     return callback(val);
//   })
//   console.log("CONTROL IS HERE")
// }

//controller.hears(['weather'], ['direct_message', 'direct_mention', 'mention'], apiaiMiddleware.hears, function(bot2, message) {
controller.hears('.*', ['message_received','direct_message', 'direct_mention', 'mention'], function(bot2, message) {
  //   return true;
    console.log("INSIDE APIAI")
    console.log("This is supposed to be the apiai response"+JSON.stringify(message, null, 2));
  //If the intent of the utterance is not recognized, and hence the action is 'input unknown', return true so that the next controller.hears can run if matched
    if(message.nlpResponse.result.action == 'input.unknown')
      return true;
  console.log("##############################################################replying#################################################\n"+user_id+"socket "+socket2.id)
    //io.emit('chat message', message.nlpResponse.result.fulfillment.speech)
    global.socket2.emit('chat message', "BOT: "+message.nlpResponse.result.fulfillment.speech);
    bot2.reply(message, message.nlpResponse.result.fulfillment.speech); 
  console.log("##############################################################replying#################################################")
//     apiai.process(message, bot2);

  //   apiai.action('input.unknown', function(message, resp, bot2) {
  //         var responseText = resp.result.fulfillment.speech;
  //         console.log(responseText);
  //         bot2.reply(message,"Sorry, I dont understand.\n \	 - dialogflow");
  // //         console.log("*************************************************************CALLING WATSON*********************************************************")
  // //         everythingWatson(bot2, message, function(intentMatched, count) {
  // //           if(intentMatched) {
  // //             return true;
  // //           }
  // //         });

  //   });

});

// apiai.all( function(message, resp, bot2) {
//         console.log("Action : "+resp.result.action);
//         var responseText = resp.result.fulfillment.speech;
//         console.log("RESPONSE TEXT : "+JSON.stringify(resp, null, 2));
//         bot2.reply(message, responseText+" \t	 - dialogflow");
// });

// apiai
//   .action('smalltalk.greetings.hello', function(message, resp, bot2) {
//         var responseText = resp.result.fulfillment.speech;
//         console.log(responseText);
//         bot2.reply(message, responseText+" \t	 - dialogflow");
//     })
//   .action('weather', function(message, resp, bot2) {
//         var responseText = resp.result.fulfillment.speech;
//         console.log(responseText);
//         bot2.reply(message, responseText+" \t	 - dialogflow");
//     })
//   .action('setReminder', function(message, resp, bot2) {
//         var responseText = resp.result.fulfillment.speech;
//         console.log(responseText);
//         bot2.reply(message, responseText+" \t	 - dialogflow");
//     })
//   .action('input.unknown', function(message, resp, bot2) {
//         var responseText = resp.result.fulfillment.speech;
//         console.log(responseText);
//         bot2.reply(message,"Sorry, I dont understand.\n \t	 - dialogflow");
//     })





//                        EVERYTHING FOR WATSON HERE
////////////////////////////////////////////////////////////////////////////////////////////////////////////
// function everythingWatson(bot2, message, callback) {
//       console.log("*************************************************************WATSON CALLED*********************************************************")
//   var flag = 1; //by default, assuming that the intent will be matched in watson
//       //controller.hears('.*', ['direct_message', 'direct_mention', 'mention'], function(bot2, message) {
//           if(message.watsonError) {
//                   bot2.reply(message, "I cannot respond to because of some techincal difficulties");
//           } else if( message.watsonData.output.nodes_visited[0] == "Anything else") {
//                   flag = 0;
//                   console.log("################################### WATSON INTENT NOT MATCHED ##################################");
//                   bot2.reply(message, "I am sorry, Watson did not understand.");
//           } else {
//                   console.log("######WATSON DATA IS ####"+JSON.stringify(message.watsonData, null, 2));
//                   bot2.reply(message, message.watsonData.output.text.join('\n')+" \	 - Watson");
//           }
//   count += 1;
  
//   //callback(1, count);
//       //});
// }



controller.hears('.*', ['direct_message', 'direct_mention', 'mention'], function(bot2, message) {
  console.log("INSIDE WATSON")
          if(message.watsonError) {
                  bot2.reply(message, "I cannot respond to because of some techincal difficulties");
          //} else if( message.watsonData.output.nodes_visited[0] == "Anything else") {
             //     console.log("################################### WATSON INTENT NOT MATCHED ##################################");
                  //bot2.reply(message, "I am sorry, Watson did not understand.");
               //   return true;
          } else {
                  console.log("######WATSON DATA IS ####"+JSON.stringify(message.watsonData, null, 2));
                  bot2.reply(message, message.watsonData.output.text.join('\n')+" \t - Watson");
          }
});




//////////////////////////////////////// TONE ANALYZER ////////////////////////////
//  WATSON TONE ANALYZER
/*
var ToneAnalyzerV3= require('watson-developer-cloud/tone-analyzer/v3');

var tone_analyzer = new ToneAnalyzerV3({
    "url": "https://gateway.watsonplatform.net/tone-analyzer/api",
        "username": "509d1830-9819-4c4d-abb1-47d2f2e72756", //  watson username for tone analyzer
        "password": "FtLIhGEsWPhS", //watson pwd
    version_date: '2017-09-21'
});

var params = {
  'tone_input' : require('./tone.json'),
  'content_type' : 'application/json'
};

tone_analyzer.tone(params, function(error, response) {
  if(error) {
    console.log(error);
  } else {
    console.log(JSON.stringify(response, null, 2));
  }
});
*/



////////////////////////////////////////////////////////////////////////////////////////////////
